# BlaBlaFood
Progetto Ingegneria del Software II

BlaBlaFood è un'applicazione che fornisce un metodo alternativo per consumare un pasto e conoscere persone.
Il nostro progetto si basa sulla progettazione di una web app dove è possibile condividere dei post con la community dove viene proposto un pranzo o una cena, da consumare a casa del ‘cuoco’ o da asporto.

L’utente che crea l’annuncio deve fornire delle indicazioni su cosa cucina, sul luogo di consumazione e sul prezzo del piatto, mentre l’utente che decide di fare richiesta del pasto deve semplicemente rispondere al post. In seguito sarà possibile aprire un canale di comunicazione tra venditore e acquirente dove sarà possibile accordarsi sulla consumazione.

L'applicazione deve implementare diverse modalità di pagamento, tra cui in contanti e online, ad esempio via paypal e revolut, così da affrontare il tema della sostenibilità anche nel mondo dei pagamenti.

Questa piattaforma:
1. favorisce la socializzazione in una maniera alternativa
1. combatte lo spreco alimentare, permettendo agli utenti di vendere il proprio cibo
1. permette di guadagnare semplicemente cucinando
1. è un'alternativa eco friendly al fast food
1. offre la possibilità di consumare un pasto homemade senza doverlo cucniare
